int main() {
    
    char *p = 0x12345;
    
    p[1] = 'a';
    
    return 0;
}
