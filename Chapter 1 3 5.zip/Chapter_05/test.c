#include <stdio.h>

int main() {
    
    printf("hello wolrd\n");
    
    return 0;
}
