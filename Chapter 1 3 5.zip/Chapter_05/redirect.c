#include <stdio.h>

int main(int argc, char *argv[]) {
    
    fputs("fputs write to stdio", stdout);
    fputs("fputs write to stderr", stderr);
    
    return 0;
}
