#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>

int main() {

    printf("hello world");
    
    _exit(0);
}
