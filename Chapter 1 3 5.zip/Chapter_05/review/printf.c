#include <stdio.h>
#include <stdlib.h>

int main() {
    printf("%d\n", printf(""));
    return 0;
}
