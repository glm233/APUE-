
void clr_fl(int fd, int flags);
