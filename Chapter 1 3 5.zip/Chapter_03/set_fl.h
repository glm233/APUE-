
void set_fl(int fd, int flags);
